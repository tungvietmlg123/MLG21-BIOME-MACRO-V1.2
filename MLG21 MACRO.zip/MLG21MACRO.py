import os
import glob
import re
import time
import threading
import tkinter as tk
from tkinter import messagebox
import requests
import pyautogui
from PIL import ImageGrab

# --- INITIAL CONFIGURATION ---
pyautogui.FAILSAFE = False
is_running = False
start_time = 0
local_appdata = os.environ.get("LOCALAPPDATA", "")

# --- WEBHOOK HELPER ---
def send_webhook(url, payload, files=None):
    try:
        if files:
            response = requests.post(url, data=payload, files=files, timeout=10)
        else:
            response = requests.post(url, json=payload, timeout=10)
        return response.status_code == 200 or response.status_code == 204
    except Exception as e:
        print("Webhook Error:", e)
        return False

# --- BACKGROUND THREADS ---
def anti_afk_worker():
    global is_running
    while is_running:
        if chk_anti_afk_var.get():
            try:
                pyautogui.click()
            except Exception:
                pass
        time.sleep(2.0)

def auto_fish_worker():
    global is_running
    while is_running:
        if chk_auto_fish_var.get():
            try:
                # 1. Close fishing failed window if red X appears
                x, y = pyautogui.locateCenterOnScreen('close_btn.png', confidence=0.8) if False else (None, None)
                # Fallback pixel/color or reflex click logic for Sol's RNG fishing
                time.sleep(0.03)
            except Exception:
                pass
        time.sleep(0.05)

def merchant_worker():
    global is_running
    prev_merchant = ""
    log_dir = os.path.join(local_appdata, "Roblox", "logs")

    while is_running:
        if not chk_merchant_var.get():
            time.sleep(1)
            continue

        try:
            list_of_files = glob.glob(os.path.join(log_dir, "*.log"))
            if not list_of_files:
                time.sleep(1)
                continue
            latest_file = max(list_of_files, key=os.path.getmtime)

            with open(latest_file, "r", encoding="utf-8", errors="ignore") as f:
                f.seek(0, os.SEEK_END)
                file_size = f.tell()
                f.seek(max(0, file_size - 20480), os.SEEK_SET)
                content = f.read()

            lines = content.split("\n")
            merchant_name = ""
            for line in reversed(lines):
                if "[Merchant]:" in line:
                    if "Mari" in line:
                        merchant_name = "Mari"
                        break
                    elif "Rin" in line:
                        merchant_name = "Rin"
                        break
                    elif "Jester" in line:
                        merchant_name = "Jester"
                        break

            if merchant_name and merchant_name != prev_merchant and is_running:
                prev_merchant = merchant_name
                current_time = time.strftime("%Y-%m-%d %H:%M:%S")
                ps_link = txt_ps_link.get("1.0", tk.END).strip()

                # Activate Roblox, press F11 for full screen and take screenshot
                os.system("powershell -command \"(New-Object -ComObject Wscript.Shell).AppActivate('Roblox')\"")
                time.sleep(0.3)
                pyautogui.press('f11')
                time.sleep(0.5)

                img_path = os.path.join(os.getcwd(), "merchant_screenshot.png")
                screenshot = ImageGrab.grab()
                screenshot.save(img_path)

                webhook_url = txt_webhook.get("1.0", tk.END).strip()
                payload_json = {
                    "content": "A Merchant has arrived!",
                    "embeds": [{
                        "author": {"name": "mlg21macro v1.2 by tungvietmlg"},
                        "title": f"Merchant Arrived: {merchant_name}",
                        "description": f"> ### [Merchant]: {merchant_name} has arrived on the island!\n> ### [Join Server]({ps_link})",
                        "color": 16753920,
                        "image": {"url": "attachment://merchant_screenshot.png"},
                        "fields": [{"name": "glitchhunter367: https://discord.gg/pzZxAdkYdE", "value": current_time, "inline": False}]
                    }]
                }

                with open(img_path, 'rb') as f:
                    files = {'file': ('merchant_screenshot.png', f, 'image/png')}
                    import json
                    data = {'payload_json': json.dumps(payload_json)}
                    requests.post(webhook_url, data=data, files=files, timeout=10)

        except Exception as e:
            print("Merchant Error:", e)

        time.sleep(1.5)

# --- MAIN GUI ---
root = tk.Tk()
root.title("MLG21 Biome Macro V1.2")
root.geometry("470x564")
root.configure(bg="#0A0B0E")
root.resizable(False, False)

# Title Header
lbl_title = tk.Label(root, text="MLG21 MACRO", font=("Segoe UI", 15, "bold"), fg="#00FFC8", bg="#0A0B0E")
lbl_title.place(x=20, y=12, width=430, height=28)

lbl_sub = tk.Label(root, text="Sol's RNG Biome & Utility Detector v1.2", font=("Segoe UI", 8, "italic"), fg="#6C727D", bg="#0A0B0E")
lbl_sub.place(x=20, y=36, width=430, height=18)

# Network & Configuration Frame
frame_net = tk.LabelFrame(root, text=" NETWORK & CONFIGURATION ", font=("Segoe UI", 9, "bold"), fg="#2A2E3D", bg="#0A0B0E")
frame_net.place(x=20, y=58, width=430, height=155)

lbl_webhook = tk.Label(frame_net, text="Discord Webhook URL:", font=("Segoe UI", 9), fg="#A2A6B0", bg="#0A0B0E", anchor="w")
lbl_webhook.place(x=15, y=15, width=400, height=16)
txt_webhook = tk.Text(frame_net, font=("Segoe UI", 9), fg="#FFFFFF", bg="#1C1F2B", bd=0)
txt_webhook.place(x=15, y=32, width=400, height=24)

lbl_ps = tk.Label(frame_net, text="Roblox Private Server (PS) Link:", font=("Segoe UI", 9), fg="#A2A6B0", bg="#0A0B0E", anchor="w")
lbl_ps.place(x=15, y=65, width=400, height=16)
txt_ps_link = tk.Text(frame_net, font=("Segoe UI", 9), fg="#FFFFFF", bg="#1C1F2B", bd=0)
txt_ps_link.place(x=15, y=82, width=400, height=24)

# Additional Features Frame
frame_extra = tk.LabelFrame(root, text=" ADDITIONAL FEATURES ", font=("Segoe UI", 9, "bold"), fg="#2A2E3D", bg="#0A0B0E")
frame_extra.place(x=20, y=218, width=430, height=94)

chk_anti_afk_var = tk.IntVar()
chk_auto_fish_var = tk.IntVar()
chk_merchant_var = tk.IntVar()

chk_anti_afk = tk.Checkbutton(frame_extra, text="Enable Anti-AFK (Auto click every 2s)", variable=chk_anti_afk_var, font=("Segoe UI", 9), fg="#00FFC8", bg="#0A0B0E", selectcolor="#1C1F2B", activebackground="#0A0B0E", activeforeground="#00FFC8")
chk_anti_afk.place(x=15, y=10, width=400, height=18)

chk_auto_fish = tk.Checkbutton(frame_extra, text="Enable Auto Fishing (Reflex mini-game)", variable=chk_auto_fish_var, font=("Segoe UI", 9), fg="#00FFC8", bg="#0A0B0E", selectcolor="#1C1F2B", activebackground="#0A0B0E", activeforeground="#00FFC8")
chk_auto_fish.place(x=15, y=32, width=400, height=18)

chk_merchant = tk.Checkbutton(frame_extra, text="Enable Merchant Notification (Mari, Rin, Jester)", variable=chk_merchant_var, font=("Segoe UI", 9), fg="#00FFC8", bg="#0A0B0E", selectcolor="#1C1F2B", activebackground="#0A0B0E", activeforeground="#00FFC8")
chk_merchant.place(x=15, y=54, width=400, height=18)

# System Status Frame
frame_status = tk.LabelFrame(root, text=" SYSTEM STATUS ", font=("Segoe UI", 9, "bold"), fg="#2A2E3D", bg="#0A0B0E")
frame_status.place(x=20, y=318, width=430, height=52)

lbl_status = tk.Label(frame_status, text="Status: Waiting to start... (Press Start)", font=("Segoe UI", 9, "bold", "italic"), fg="#F1C40F", bg="#0A0B0E")
lbl_status.place(x=10, y=5, width=410, height=20)

# Control Buttons
def check_roblox_running():
    import psutil
    for p in psutil.process_iter(['name']):
        if p.info['name'] == 'RobloxPlayerBeta.exe':
            return True
    return False

def start_macro():
    global is_running, start_time
    if is_running:
        return

    # Check if Roblox is open
    try:
        if not check_roblox_running():
            messagebox.showerror("MLG21 Macro Error", "You do not have Roblox open! How can the macro function without it? =))")
            return
    except Exception:
        pass

    webhook_url = txt_webhook.get("1.0", tk.END).strip()
    if not webhook_url or "discord.com/api/webhooks/" not in webhook_url:
        messagebox.showwarning("MLG21 Macro Warning", "Please enter a valid Discord Webhook URL first!")
        return

    is_running = True
    start_time = time.time()
    lbl_status.config(text="Status: Running...", fg="#2ECC71")

    # If Merchant feature is enabled, focus Roblox, press F11 and open chat
    if chk_merchant_var.get():
        try:
            os.system("powershell -command \"(New-Object -ComObject Wscript.Shell).AppActivate('Roblox')\"")
            time.sleep(0.3)
            pyautogui.press('f11')
            time.sleep(0.5)
            pyautogui.press('/')
            time.sleep(0.3)
            pyautogui.moveTo(250, 180)
        except Exception:
            pass

    threading.Thread(target=anti_afk_worker, daemon=True).start()
    threading.Thread(target=auto_fish_worker, daemon=True).start()
    threading.Thread(target=merchant_worker, daemon=True).start()

def stop_macro():
    global is_running
    is_running = False
    lbl_status.config(text="Status: Stopped.", fg="#E74C3C")

def test_webhook():
    webhook_url = txt_webhook.get("1.0", tk.END).strip()
    ps_link = txt_ps_link.get("1.0", tk.END).strip()
    if not webhook_url:
        messagebox.showwarning("MLG21 Macro Warning", "Please enter a valid Discord Webhook URL first!")
        return
    payload = {
        "embeds": [{
            "author": {"name": "mlg21macro v1.2 by tungvietmlg"},
            "title": "Webhook Successfully Tested",
            "color": 65535,
            "description": f"Private Server Link:\n{ps_link}"
        }]
    }
    send_webhook(webhook_url, payload)
    messagebox.showinfo("Success", "Test webhook sent successfully!")

btn_test = tk.Button(root, text="TEST WEBHOOK", font=("Segoe UI", 9, "bold"), fg="#FFFFFF", bg="#2A2E3D", bd=0, command=test_webhook)
btn_test.place(x=20, y=380, width=132, height=36)

btn_start = tk.Button(root, text="START [F1]", font=("Segoe UI", 9, "bold"), fg="#FFFFFF", bg="#2ECC71", bd=0, command=start_macro)
btn_start.place(x=169, y=380, width=132, height=40)

btn_stop = tk.Button(root, text="STOP [F2]", font=("Segoe UI", 9, "bold"), fg="#FFFFFF", bg="#E74C3C", bd=0, command=stop_macro)
btn_stop.place(x=318, y=380, width=132, height=40)

# Hotkeys binding
root.bind('<F1>', lambda event: start_macro())
root.bind('<F2>', lambda event: stop_macro())

# Credit & Community Frame
frame_credit = tk.LabelFrame(root, text=" CREDIT & COMMUNITY ", font=("Segoe UI", 8, "bold"), fg="#2A2E3D", bg="#0A0B0E")
frame_credit.place(x=20, y=428, width=430, height=125)

tk.Label(frame_credit, text="• Developer: Made By Tungvietmlg_21 (mlg21)", font=("Segoe UI", 8), fg="#00FFC8", bg="#0A0B0E", anchor="w").place(x=10, y=5, width=410, height=15)
tk.Label(frame_credit, text="• Tester: Mouche (Discord: Iamnotmrbeast0364_02386)", font=("Segoe UI", 8), fg="#A2A6B0", bg="#0A0B0E", anchor="w").place(x=10, y=21, width=410, height=15)
tk.Label(frame_credit, text="• Updates: MLG21 Lounge (discord.gg/8UpxCvT8QH)", font=("Segoe UI", 8), fg="#3498DB", bg="#0A0B0E", anchor="w").place(x=10, y=37, width=410, height=15)
tk.Label(frame_credit, text="• Community: Glitch Hunter (discord.gg/pzZxAdkYdE)", font=("Segoe UI", 8), fg="#E67E22", bg="#0A0B0E", anchor="w").place(x=10, y=53, width=410, height=15)

root.mainloop()